public class Card {

    public static final int HEARTS = 0;
    public static final int SPADES = 1;
    public static final int CLUBS = 2;
    public static final int DIAMONDS = 3;

    public static final int JACK = 11;
    public static final int QUEEN = 12;
    public static final int KING = 13;
    public static final int ACE = 14;

    private int m_value;
    private int m_suit;

    public Card() {
        m_value = ACE;
        m_suit = SPADES;
    }

    public Card(int value, int suit) {
        m_value = value;
        m_suit = suit;
    }

    public Card(Card other) {
        m_value = other.m_value;
        m_suit = other.m_suit;
    }

    public int getValue() {
        return m_value;
    }

    public void setValue(int value) {
        m_value = value;
    }

    public int getSuit() {
        return m_suit;
    }

    public void setSuit(int suit) {
        m_suit = suit;
    }

    @Override
    public String toString() {
        String valueStr = "";
        switch (m_value) {
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
                valueStr = String.valueOf(m_value);
                break;
            case JACK:
                valueStr = "Jack";
                break;
            case QUEEN:
                valueStr = "Queen";
                break;
            case KING:
                valueStr = "King";
                break;
            case ACE:
                valueStr = "Ace";
                break;
        }

        String suitStr = "";
        switch (m_suit) {
            case HEARTS:
                suitStr = "Hearts";
                break;
            case SPADES:
                suitStr = "Spades";
                break;
            case CLUBS:
                suitStr = "Clubs";
                break;
            case DIAMONDS:
                suitStr = "Diamonds";
                break;
        }

        return valueStr + " of " + suitStr;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Card) {
            Card other = (Card) obj;
            return m_value == other.m_value;
        }
        return false;
    }
}
