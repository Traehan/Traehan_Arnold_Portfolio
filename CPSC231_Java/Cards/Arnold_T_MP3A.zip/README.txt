Traehan Arnold 
2428537
tarnold@chapman.edu
CPSC 231 Section 05
MP3 Cards
Card.java, Deck.java, Dealer.java, TestCards.java README.txt
Notes