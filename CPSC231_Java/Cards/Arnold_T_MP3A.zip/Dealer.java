import java.util.LinkedList;
import java.util.Random;

public class Dealer {
    private Deck m_deck;
    
    public Dealer() {
        m_deck = new Deck();
    }
    
    public LinkedList<Card> deals(int n) {
        LinkedList<Card> dealtCards = new LinkedList<>();
        int deckSize = m_deck.size();
        
        // return an empty list if the deck is empty or n is 0
        if (deckSize == 0 || n == 0) {
            return dealtCards;
        }
        
        // deal n cards randomly from the deck
        Random rand = new Random();
        for (int i = 0; i < n; i++) {
            int index = rand.nextInt(deckSize);
            dealtCards.add(m_deck.deal());
            deckSize--;
        }
        
        return dealtCards;
    }
    
    public int size() {
        return m_deck.size();
    }
    
    public String toString() {
        return m_deck.toString();
    }
}
