import java.util.LinkedList;
import java.util.Random;

public class Deck {

    private LinkedList<Card> m_cards;

    public Deck() {
        m_cards = new LinkedList<>();
        for (int suit = Card.HEARTS; suit <= Card.DIAMONDS; suit++) {
            for (int value = 2; value <= 14; value++) {
                m_cards.add(new Card(value, suit));
            }
        }
    }

    public Deck(Deck other) {
        m_cards = new LinkedList<>();
        for (Card card : other.m_cards) {
            m_cards.add(new Card(card));
        }
    }

    public String toString() {
        return m_cards.toString();
    }

    public int size() {
        return m_cards.size();
    }

    public Card deal() {
        if (m_cards.isEmpty()) {
            return null;
        }
        int index = new Random().nextInt(m_cards.size());
        return m_cards.remove(index);
    }
}
