abstract class Account {
    protected String name;

    public Account(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}