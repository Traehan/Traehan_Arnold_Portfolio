Traehan Arnold 
2428537
tarnold@chapman.edu
CPSC 350 
Robber Language Projects
FileProcessor.cpp, FileProcessor.h, Model.cpp, Model.h, Tanslator.cpp, Tanslator.h, main.cpp
Notes: got help from the link and from chatgpt to create my html file.