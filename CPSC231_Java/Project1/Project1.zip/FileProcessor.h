#ifndef FILEPROCESSOR_H
#define FILEPROCESSOR_H

#include <iostream>
#include <fstream>
using namespace std;


class FileProcessor{

    public:
        FileProcessor();
        ~FileProcessor();
        void processFile(string input_File, string htmlFile);
    //Aux Functions

    





};

#endif